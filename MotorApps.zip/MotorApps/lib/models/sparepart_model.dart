import 'package:flutter/cupertino.dart';
import 'package:firebase_database/firebase_database.dart';

class MotorModel {
  final String? key;
  String? img;
  String? name;
  String? company;
  double? price;
  bool? isselected;
  Color? color;

  MotorModel(
      {this.key,
      this.name,
      this.company,
      this.price,
      this.isselected,
      this.color});

  MotorModel.fromSnapshot(DataSnapshot snapshot) : key = snapshot.key,   //proses sending data ke realtime database
        name = snapshot.value['name'],
        company = snapshot.value['company'],
        price = snapshot.value['price'],
        isselected = snapshot.value['isselected'],
        color = snapshot.value['color'];

  Map<String, dynamic> toJson() => {  //agar data dapat di baca dari bentuk Array ke bentuk JSON, karena flutter
    'name' : name,              //hanya dapat membaca data dalam bentuk JSON
    'company' : company,
    'price' : price,
    'isselected' : isselected,
    'color' : color,
  };
}
